<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class Post extends Model
{
    protected $fillable = [
        'user_id', 'nlikes', 'content'
    ];

    public function user(){
        // con questa funzione dato un post possiamo risalire all'utente a cui appartiene
		return $this->belongsTo('App\Models\User');  // un certo post appartiene ad un utente
	}

    public function likes(){
		return $this->belongsToMany('App\Models\User', 'likes'); // un certo post può avere molti like
	}
}
