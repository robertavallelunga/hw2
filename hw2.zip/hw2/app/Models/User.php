<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class User extends Model
{
    protected $fillable = [
        'username', 'password', 'name', 'surname', 'email'
    ];

    public function posts() // questa funzione ci permette di raggiungere tutti i post dell'utente
    {
        return $this->hasMany('App\Models\Post');  // un utente può avere molti post
    }

    public function likes() {
        return $this->belongsToMany('App\Models\Post'); // un utente può mettere molti like
    }
}
