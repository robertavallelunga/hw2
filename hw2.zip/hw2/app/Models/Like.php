<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class Like extends Model
{
    public function user(){
        // dato un like possiamo risalire all'utente a cui appartiene
		return $this->belongsTo('App\Models\User');  // un certo like appartiene ad un utente
	}

    public function posts(){
        // dato un like possiamo risalire al post a cui appartiene
		return $this->belongsTo('App\Models\Post'); // un certo like appartiene ad un post
	}

}
