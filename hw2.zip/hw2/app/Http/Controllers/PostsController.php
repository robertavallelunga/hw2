<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use App\Models\User;
use App\Models\Post;
use App\Models\Like;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class PostsController extends BaseController{


    public function home(){
		// Controllo accesso
		if(!Session::get('user_id')){
			return redirect('login');
		}
		// Leggiamo username
		$user = User::find(Session::get('user_id'));
		return view('home')->with('username', $user->username);
    }


	public function list(){
		// Controllo accesso
		if(!Session::get('user_id')){
			return [];
		}
		// Leggiamo i posts

        $current_userid = Session::get('user_id');

         $posts = Post::join('users', 'posts.user_id', '=', 'users.id')
        ->select('users.id AS userid', 'users.name AS name', 'users.surname AS surname', 'users.username AS username', 'posts.id AS postid',
        'posts.content AS content', 'posts.created_at AS time', 'posts.nlikes AS nlikes')
        ->orderBy('posts.id', 'DESC')
        ->get();

        $postArray = array();
        foreach($posts as $post){
            $time = $this->getTime($post['time']);
            Like::join('posts', 'likes.post_id', '=', 'posts.id')
            ->where('likes.post_id', $post['postid'])
            ->where('likes.user_id', $current_userid)->exists()?$liked=1:$liked=0;

            $postArray[] = array('userid' => $post['userid'], 'name' => $post['name'], 'surname' => $post['surname'],
            'username' => $post['username'], 'postid' => $post['postid'], 'content' => json_decode($post['content']),
            'nlikes' => $post['nlikes'], 'time' => $time, 'liked' => $liked ); 
        }
        echo json_encode($postArray);

    }

    public function getTime($timestamp) {
        // Calcola il tempo trascorso dalla pubblicazione del post
        $old = strtotime($timestamp);
        $diff = time() - $old;
        $old = date('d/m/y', $old);

        if ($diff /60 <1) {
            return intval($diff%60)." secondi fa";
        } else if (intval($diff/60) == 1)  {
            return "Un minuto fa";
        } else if ($diff / 60 < 60) {
            return intval($diff/60)." minuti fa";
        } else if (intval($diff / 3600) == 1) {
            return "Un'ora fa";
        } else if ($diff / 3600 <24) {
            return intval($diff/3600) . " ore fa";
        } else if (intval($diff/86400) == 1) {
            return "Ieri";
        } else if ($diff/86400 < 30) {
            return intval($diff/86400) . " giorni fa";
        } else {
            return $old;
        }
    }


    public function add(Request $formData){
		// Controllo accesso
		if(!Session::get('user_id')){
            return [];
		}

        print_r($formData->poster);
		// Creiamo nuovo post
        $post = new Post;
		$post->user_id = Session::get('user_id');
        $post->nlikes = 0;
        $json_content = [
            'url' => $formData->poster,
            'film' => $formData->film
        ];
        $post->content = json_encode($json_content, JSON_UNESCAPED_SLASHES);  
		$post->save();
    }

}
?>
