<?php
namespace App\Http\Controllers;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\User;
use App\Models\Like;

class LikeController extends BaseController
{
    public function liked(Request $formData) {

        $user = User::find(session('user_id'));
        Post::find($formData->postid)->likes()->toggle($user->id);

        $post = Post::find($formData->postid);
        return response()->json([
            'nlikes' => $post->nlikes,
        ]);
    } 
}
