<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;
use App\Models\User;
use App\Models\Post;
use Illuminate\Support\Facades\Session;

class HomeController extends BaseController {

    public function index() {
        // Controllo accesso
		if(!Session::get('user_id')){
			return redirect('login');
		}

        $session_id = session('user_id');
        $user = User::find($session_id);
        Session::put('username', $user->username);
        if (!isset($user))
            return view('welcome');

        return view("home")->with('username', session('username'));
    }
}
?>
