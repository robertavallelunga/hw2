<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller {


    public function login(){
        if (session('user_id') != null){
            $user = User::find(session('user_id'));
            Session::put('username', $user->username);
            return redirect('home')->with('username', $user->username);
        }
        else {
            return view('login')->with('csrf_token', csrf_token());
        }

    }


    public function checkLogin() {
        // Se l'utente è già loggato
        if (session('user_id')){
            return redirect('home');
        }
        // Controlliamo se l'utente e la password sono presenti nel database
        $user = User::where('username', request('username'))->first();
        if(!$user || !password_verify(request('password'), $user->password))
        {
            return redirect('login')->withInput();
        }
      
        if($user !== null) {
            Session::put('user_id', $user->id);
            Session::put('username', $user->username);
            return redirect('home')->with('username', $user->username);
        }
    }


	public function logout(){
		// Elimina i dati di sessione
		Session::flush();
        return redirect('login');
    }
}
?>
