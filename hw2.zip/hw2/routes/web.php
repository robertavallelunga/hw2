<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('login', "App\Http\Controllers\LoginController@login")->name("login");
Route::post('login', "App\Http\Controllers\LoginController@checkLogin");
Route::get('logout', "App\Http\Controllers\LoginController@logout");

Route::get('register', "App\Http\Controllers\RegisterController@index")->name('register');
Route::post('register', "App\Http\Controllers\RegisterController@create");
Route::get('register/email/{query}', "App\Http\Controllers\RegisterController@checkEmail");
Route::get('register/username/{q}', "App\Http\Controllers\RegisterController@checkUsername");


Route::get('home', "App\Http\Controllers\HomeController@index")->name('home');
Route::get('posts', "App\Http\Controllers\PostsController@home");
Route::get('posts/list', "App\Http\Controllers\PostsController@list");
Route::post('posts/add/', "App\Http\Controllers\PostsController@add");
//Route::get('likes/liked/{postid}', "App\Http\Controllers\LikeController@liked");
Route::post('likes/liked', "App\Http\Controllers\LikeController@liked");

