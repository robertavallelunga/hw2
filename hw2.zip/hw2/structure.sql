use database hw2

CREATE TABLE users (
    id integer primary key auto_increment,
    username varchar(16) not null unique,
    password varchar(255) not null,
    name varchar(255) not null,
    surname varchar(255) not null,
    email varchar(255) not null unique,
	//nposts integer default 0,
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) Engine = InnoDB;

CREATE TABLE posts (
    id integer primary key auto_increment,
    user_id integer not null,
    time timestamp not null default current_timestamp,
    nlikes integer default 0,
    content json,
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    foreign key(user_id) references users(id) on delete cascade on update cascade
) Engine = InnoDB;

CREATE TABLE likes (
	//id integer primary key auto_increment,
    user_id integer not null,
    post_id integer not null,
    index xuser(user_id),
    index xpost(post_id),
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    foreign key(user_id) references users(id) on delete cascade on update cascade,
    foreign key(post_id) references posts(id) on delete cascade on update cascade,
    primary key(user_id, post_id)
) Engine = InnoDB;


DELIMITER //
CREATE TRIGGER likes_trigger
AFTER INSERT ON likes
FOR EACH ROW
BEGIN
UPDATE posts 
SET nlikes = nlikes + 1
WHERE id = new.post_id;
END //
DELIMITER ;


DELIMITER //
CREATE TRIGGER unlikes_trigger
AFTER DELETE ON likes
FOR EACH ROW
BEGIN
UPDATE posts 
SET nlikes = nlikes - 1
WHERE id = old.post_id;
END //
DELIMITER ;

!!!!!Da eliminare!!!!!
DELIMITER //
CREATE TRIGGER posts_trigger
AFTER INSERT ON posts
FOR EACH ROW
BEGIN
UPDATE users 
SET nposts = nposts + 1
WHERE id = new.user_id;
END //
DELIMITER ;


