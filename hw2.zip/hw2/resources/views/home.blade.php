@extends('layouts.guest')

@section('title', '| Home')

@section ('style')
<link rel='stylesheet' href="{{ asset('css/home.css') }}" >
@endsection

@section('script')
<script src="{{ asset('js/home.js') }}" defer></script>

@endsection

@section('content')

<?php
session_start();
?>

<html>

   <head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="utf-8">
        <script>const BASE_URL = "{{ url('/') }}/"</script>
   </head>

   <body>
      <header>
         <div id="barra"><div>
            <div> <button><a href="{{ route('home') }}"> HOME </a></button></div>
            <div ><button class="post"> CREA POST </button></div>
         </div>
         </div>
         <div>
            <button> <a href="logout"> LOG OUT </a></button>
         </div>
      </header>

      <main>
         <section>
            <div> Benvenuto <?php echo session('username'); ?></div>
            <form id="films" >
                @csrf
               <label>Film da condividere</label>
               <input type="text" name="film" id="film" />
               <input type="submit" id="submit" value="Condividi" />
            </form>

         </section>
         <section id="ris_ricerca"></section>
      </main>

   </body>
</html>
