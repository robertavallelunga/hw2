@extends('layouts.guest')

@section('title', '| Registrazione')

@section ('style')
<link rel='stylesheet' href="{{ asset('css/registrazione.css') }}" >
@endsection

@section('script')
<script src="{{ asset('js/registrazione.js') }}" defer></script>
<script type="text/javascript">
    const REGISTER_ROUTE = "{{route('register')}}";
</script>
@endsection

@section('content')

<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="utf-8">
    </head>

    <body>
        <main>
            <section>
                <h1> Crea il tuo account </h1>
                <?php
                // verifica la presenza di errori
                if (isset($error)) {
                    for ($i=0; $i < count($error); $i++) {
                        echo "<span class'error'>$error[$i]</span>";
                    }
                }
                ?>
                <form name='registrazione' action="{{route('register')}}" method='post'>
                    @csrf
                    <div class="name">
                        <div><label for='name'> Nome  </label></div>
                        <div><input type='text' name='name' id='name' value='{{ old("name") }}'></div>
                        <span></span>
                    </div>
                    <div class="surname">
                        <div><label for='surname'> Cognome </label></div>
                        <div><input type='text' name='surname' id='surname' value='{{ old("surname") }}'></div>
                    </div>
                    <div class="username">
                        <div><label for='username'>Nome utente </label></div>
                        <div><input type='text' name='username' id='username' value='{{ old("username") }}'></div>
                        <span></span>
                    </div>

                    <div class="email">
                        <div><label for='email'>Email </label></div>
                        <div><input type='text' name='email' id='email' value='{{ old("email") }}'></div>
                        <span></span>
                    </div>

                    <div class="password">
                        <div><label for='password'>Password </label></div>
                        <div><input type='password' name='password' id='password' value='{{ old("password") }}'></div>
                        <span></span>
                    </div>

                    <div class="confirmPassword">
                        <div><label for='confirm_password'>Conferma password </label></div>
                        <div><input type='password' name='confirm_password' id='confirm_password' value='{{ old("confirm_password") }}'></div>
                        <span></span>
                    </div>

                    <div>
                        &nbsp;<input id='submit' type="submit">
                    </div>

                    <div> Hai già un account? <a href="{{ route('login') }}">Accedi</a> </div>

                </form>
            </section>
        </main>

    </body>

</html>
