<?php $__env->startSection('title', '| Registrazione'); ?>

<?php $__env->startSection('style'); ?>
<link rel='stylesheet' href="<?php echo e(asset('css/registrazione.css')); ?>" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/registrazione.js')); ?>" defer></script>
<script type="text/javascript">
    const REGISTER_ROUTE = "<?php echo e(route('register')); ?>";
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="utf-8">
    </head>

    <body>
        <main>
            <section>
                <h1> Crea il tuo account </h1>
                <?php
                // verifica la presenza di errori
                if (isset($error)) {
                    for ($i=0; $i < count($error); $i++) {
                        echo "<span class'error'>$error[$i]</span>";
                    }
                }
                ?>
                <form name='registrazione' action="<?php echo e(route('register')); ?>" method='post'>
                    <?php echo csrf_field(); ?>
                    <div class="name">
                        <div><label for='name'> Nome  </label></div>
                        <div><input type='text' name='name' id='name' value='<?php echo e(old("name")); ?>'></div>
                        <span></span>
                    </div>
                    <div class="surname">
                        <div><label for='surname'> Cognome </label></div>
                        <div><input type='text' name='surname' id='surname' value='<?php echo e(old("surname")); ?>'></div>
                    </div>
                    <div class="username">
                        <div><label for='username'>Nome utente </label></div>
                        <div><input type='text' name='username' id='username' value='<?php echo e(old("username")); ?>'></div>
                        <span></span>
                    </div>

                    <div class="email">
                        <div><label for='email'>Email </label></div>
                        <div><input type='text' name='email' id='email' value='<?php echo e(old("email")); ?>'></div>
                        <span></span>
                    </div>

                    <div class="password">
                        <div><label for='password'>Password </label></div>
                        <div><input type='password' name='password' id='password' value='<?php echo e(old("password")); ?>'></div>
                        <span></span>
                    </div>

                    <div class="confirmPassword">
                        <div><label for='confirm_password'>Conferma password </label></div>
                        <div><input type='password' name='confirm_password' id='confirm_password' value='<?php echo e(old("confirm_password")); ?>'></div>
                        <span></span>
                    </div>

                    <div>
                        &nbsp;<input id='submit' type="submit">
                    </div>

                    <div> Hai già un account? <a href="<?php echo e(route('login')); ?>">Accedi</a> </div>

                </form>
            </section>
        </main>

    </body>

</html>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hw2\resources\views/register.blade.php ENDPATH**/ ?>