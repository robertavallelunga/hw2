<?php $__env->startSection('title', '| Accedi'); ?>

<?php $__env->startSection('style'); ?>
<link rel='stylesheet' href="<?php echo e(asset('css/login.css')); ?>" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="utf-8">

    </head>

    <body>
        <main>
            <section>
                <h1> Accedi </h1>
                <form name='login' action="<?php echo e(route('login')); ?>" method='post'>
                    <?php echo csrf_field(); ?>
                    <div>
                        <label for = "username"> Username <input type='text' name='username'></label>
                    </div>

                    <div>
                        <label> Password <input type='password' name='password'> </label>
                    </div>

                    <div>
                        <input id='submit' type="submit">
                    </div>
                </form>
                Non hai un account? <a href="<?php echo e(route('register')); ?>">Registrati</a>
            </section>

        </main>

    </body>

</html>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hw2\resources\views/login.blade.php ENDPATH**/ ?>