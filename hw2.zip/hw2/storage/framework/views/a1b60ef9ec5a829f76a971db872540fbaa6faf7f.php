<?php $__env->startSection('title', '| Home'); ?>

<?php $__env->startSection('style'); ?>
<link rel='stylesheet' href="<?php echo e(asset('css/home.css')); ?>" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/home.js')); ?>" defer></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php
session_start();
?>

<html>

   <head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="utf-8">
        <script>const BASE_URL = "<?php echo e(url('/')); ?>/"</script>
   </head>

   <body>
      <header>
         <div id="barra"><div>
            <div> <button><a href="<?php echo e(route('home')); ?>"> HOME </a></button></div>
            <div ><button class="post"> CREA POST </button></div>
         </div>
         </div>
         <div>
            <button> <a href="logout"> LOG OUT </a></button>
         </div>
      </header>

      <main>
         <section>
            <div> Benvenuto <?php echo session('username'); ?></div>
            <form id="films" >
                <?php echo csrf_field(); ?>
               <label>Film da condividere</label>
               <input type="text" name="film" id="film" />
               <input type="submit" id="submit" value="Condividi" />
            </form>

         </section>
         <section id="ris_ricerca"></section>
      </main>

   </body>
</html>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hw2\resources\views/home.blade.php ENDPATH**/ ?>